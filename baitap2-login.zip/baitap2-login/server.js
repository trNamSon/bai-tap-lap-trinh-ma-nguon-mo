const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();

// Middleware để parse JSON body
app.use(express.json());
// Serve static files từ thư mục public
app.use(express.static("public"));

// Route mặc định trả về trang login
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Route xử lý đăng nhập
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  // Đọc file user.txt
  fs.readFile("user.txt", "utf8", (err, data) => {
    if (err) {
      console.error("Error reading user file:", err);
      return res.json({ success: false });
    }

    // Parse thông tin user từ file
    const [storedUsername, storedPassword, userName] = data.trim().split("|");

    // Kiểm tra username và password
    if (username === storedUsername && password === storedPassword) {
      res.json({ success: true, user: userName });
    } else {
      res.json({ success: false });
    }
  });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
