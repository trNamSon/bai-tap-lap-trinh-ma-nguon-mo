const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Read the vehicle plates data
const vehiclePlatesData = JSON.parse(
  fs.readFileSync("vietnameseVehiclePlates.txt", "utf8")
);

// Get all cities
app.get("/api/cities", (req, res) => {
  const cities = vehiclePlatesData.map((item) => item.city);
  res.json(cities);
});

// Get plate number by city
app.get("/api/plate/:city", (req, res) => {
  const city = req.params.city;
  const plateInfo = vehiclePlatesData.find((item) => item.city === city);
  if (plateInfo) {
    res.json({ plateNo: plateInfo.plate_no });
  } else {
    res.status(404).json({ error: "City not found" });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
