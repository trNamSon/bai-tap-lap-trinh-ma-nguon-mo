document.addEventListener("DOMContentLoaded", () => {
  const citySelect = document.getElementById("citySelect");
  const resultDiv = document.getElementById("result");

  // Fetch cities and populate select
  fetch("http://localhost:3000/api/cities")
    .then((response) => response.json())
    .then((cities) => {
      cities.forEach((city) => {
        const option = document.createElement("option");
        option.value = city;
        option.textContent = city;
        citySelect.appendChild(option);
      });
    })
    .catch((error) => {
      console.error("Error fetching cities:", error);
      resultDiv.textContent = "Error loading cities";
    });

  // Handle city selection
  citySelect.addEventListener("change", (e) => {
    const selectedCity = e.target.value;
    if (!selectedCity) {
      resultDiv.textContent = "";
      return;
    }

    fetch(`http://localhost:3000/api/plate/${encodeURIComponent(selectedCity)}`)
      .then((response) => response.json())
      .then((data) => {
        resultDiv.textContent = `Biển số xe: ${data.plateNo}`;
      })
      .catch((error) => {
        console.error("Error fetching plate number:", error);
        resultDiv.textContent = "Error loading plate number";
      });
  });
});
